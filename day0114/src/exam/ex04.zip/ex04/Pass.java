package exam.ex04;

public class Pass {
	
	int a,b,c;
	
	public int sum(int a, int b, int c) {
		
		return a + b + c;
	}
	
	public double avg(int a, int b, int c) {
		return (double) (a+b+c)/3;
	}

}
