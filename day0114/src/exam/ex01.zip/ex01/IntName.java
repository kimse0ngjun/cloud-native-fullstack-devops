package exam.ex01;

public class IntName {

	int a, b;
	
	public IntName() {
	}
	
	public int add(int a, int b) {
		return a + b;
	}
	
	public int minus(int a, int b) {
		return a - b;
	}
	
	public int mul(int a, int b) {
		return a * b;
	}
	
	public int div(int a, int b) {
		return a / b;
	}
	
}
